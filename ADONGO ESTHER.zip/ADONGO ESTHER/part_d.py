def is_same_string(input_string, compare_string):
    return input_string == compare_string


input_string = "hello"
compare_string = "hello"
print("Strings are the same:", is_same_string(input_string, compare_string))
